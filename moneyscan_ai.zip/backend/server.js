const express = require('express');
const cors = require('cors');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage });

app.post('/api/check-currency', upload.single('image'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No image uploaded" });

    const fakeResult = {
        currency: "USD",
        real: Math.random() > 0.5
    };

    res.json(fakeResult);
});

app.listen(4000, () => console.log("Backend running on port 4000"));
