const TelegramBot = require('node-telegram-bot-api');
const token = "YOUR_BOT_TOKEN_HERE";

const bot = new TelegramBot(token, { polling: true });

bot.on('photo', (msg) => {
    bot.sendMessage(msg.chat.id, "Image received! AI checking will be added soon.");
});
